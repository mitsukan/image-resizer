

def handler(event, context):

    print("hello world!")